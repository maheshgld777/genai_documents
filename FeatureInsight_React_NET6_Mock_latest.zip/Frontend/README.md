# FeatureInsight React Frontend

To run:
```bash
npm install
npm start
```