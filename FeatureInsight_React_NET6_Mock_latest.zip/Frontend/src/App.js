
import React, { useState } from 'react';

function App() {
  const [story, setStory] = useState('');
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    const response = await fetch('http://localhost:5000/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ story })
    });
    const data = await response.json();
    setResult(data);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h2>FeatureInsight</h2>
      <textarea
        rows="4"
        cols="60"
        placeholder="Enter your user story..."
        value={story}
        onChange={(e) => setStory(e.target.value)}
      />
      <br />
      <button onClick={handleSubmit} style={{ marginTop: '1rem' }}>Analyze</button>
      {result && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Mocked Analysis Result:</h3>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;
