
using Microsoft.AspNetCore.Mvc;

namespace FeatureInsight.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AnalyzeController : ControllerBase
    {
        [HttpPost]
        public IActionResult Post([FromBody] UserStoryRequest request)
        {
            var result = new
            {
                impactAreas = new[] { "Authentication", "Database Schema", "Logging Service" },
                riskLevel = "Medium",
                notes = "Changes to user roles might affect permission validation."
            };
            return Ok(result);
        }
    }

    public class UserStoryRequest
    {
        public string Story { get; set; }
    }
}
